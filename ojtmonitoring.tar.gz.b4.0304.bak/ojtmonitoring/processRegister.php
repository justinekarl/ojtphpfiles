<?php

require_once 'db_config.php';
$response = array();

$test = array();


if (isset($_POST['user_name']) && isset($_POST['password'])) {
    error_log("sign up -".$_POST['user_name']."-".$_POST['password']);
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];
    $accounttype = intval($_POST['accounttype']);
    $full_name= $_POST['full_name'];
    $phonenumber = $_POST['phonenumber'];
    $email = $_POST['email'];


    if($accounttype == 1){
        $student_number= $_POST['student_number'];
        $college = $_POST['college'];
        $address = $_POST['address'];
    }

    if($accounttype == 2){
        $department = $_POST['department'];
        $teacherNumber = $_POST['phonenumber'];
        $college = $_POST['college'];
    }

    if($accounttype==3){
        $companyType = $_POST['companyType'];
        $address = $_POST['address'];
        //$teacherNumber = $_POST['phonenumber'];
    }


    
    $queryTo = "SELECT count(*) > 0 cnt FROM user where username='{$user_name}' and case when 1 = {$accounttype} then studentnumber ='{$student_number}' when 2 = {$accounttype} then teachernumber = '{$teacherNumber}' else 1=1 end ";
    $result_checker = mysqli_query($link,$queryTo);
    $checker = (int) mysqli_fetch_assoc($result_checker)["cnt"];

    error_log("register.php checker_restult".print_r($result_checker,true));

    error_log("register.php checker_restult".print_r($queryTo,true));


    $insertedId;

    if($checker === 0){

        if($accounttype === 1) {
            $studentQry = "INSERT INTO user(username,password,studentnumber,name,college,address,phonenumber,accounttype,email) VALUES('$user_name', '$password','$student_number','$full_name','$college','$address','$phonenumber','$accounttype','$email')";
            $result=mysqli_query($link,
                $studentQry);

            error_log("studentQry".print_r($studentQry,true));



            $insertedId = mysqli_insert_id($link);
            error_log($insertedId);

            $query1 = "SELECT * FROM user WHERE id = ".$insertedId;

             $result_student = mysqli_query($link,$query1);

             $response['returned_id'] = $insertedId;


             echo json_encode($response);


        }

        if($accounttype == 2) {

            $teacherQry = "INSERT INTO user(username,password,teachernumber,name,department,phonenumber,accounttype,email,college) VALUES('$user_name', '$password','$teacherNumber','$full_name','$department','$phonenumber','$accounttype','$email','$college')";
            $result=mysqli_query($link,$teacherQry);

            error_log("studentQry".print_r($teacherQry,true));


        }

        if($accounttype == 3){
        

            $companyQry = "INSERT INTO user(username,password,name,address,department,phonenumber,accounttype,email) VALUES('$user_name', '$password','$full_name','$address','$companyType','$phonenumber','$accounttype','$email')";
            $result=mysqli_query($link,$companyQry
                );
            $id = mysqli_insert_id($link);
            error_log($id);


            $companyProfileQry = "INSERT INTO company_profile(user_id) 
                                  VALUES ('$id')
                                 ";

            $result=mysqli_query($link,$companyProfileQry);


        }



    }
} 
?>